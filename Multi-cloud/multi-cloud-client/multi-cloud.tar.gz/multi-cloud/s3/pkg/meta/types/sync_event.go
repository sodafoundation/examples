package types

type BucketUsageEvent struct {
	Usage      int64
	BucketName string
}
