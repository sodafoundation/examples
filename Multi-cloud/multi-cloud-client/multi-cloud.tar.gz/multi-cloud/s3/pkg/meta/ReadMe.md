# Meta layer

Storage metadata manipulation helper functions for YIG, including a cache layer for HBase, build on Redis.

Move more methods into this package as more patterns emerge

