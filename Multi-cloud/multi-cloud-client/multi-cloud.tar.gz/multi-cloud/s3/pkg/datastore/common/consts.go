package common

const (
	CONTEXT_KEY_SIZE           = "size"
	CONTEXT_KEY_MD5            = "md5"
	CONTEXT_KEY_SSE_TYPE       = "sse_type"
	CONTEXT_KEY_ENCRYPTION_KEY = "encrypt_key"
	CONTEXT_KEY_CIPHER_KEY     = "cipher_key"
)
