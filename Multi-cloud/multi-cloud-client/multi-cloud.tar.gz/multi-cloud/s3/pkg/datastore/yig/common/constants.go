package common

const (
	MIN_PART_SIZE = 128 << 10 // 128KB
)
