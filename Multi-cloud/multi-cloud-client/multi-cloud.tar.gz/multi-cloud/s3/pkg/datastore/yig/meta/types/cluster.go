package types

type Cluster struct {
	Fsid   string
	Pool   string
	Weight int
}
