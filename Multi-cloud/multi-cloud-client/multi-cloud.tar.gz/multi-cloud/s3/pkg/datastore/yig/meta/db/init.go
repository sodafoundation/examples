package db

import (
	_ "github.com/opensds/multi-cloud/s3/pkg/datastore/yig/meta/db/tidb"
)
