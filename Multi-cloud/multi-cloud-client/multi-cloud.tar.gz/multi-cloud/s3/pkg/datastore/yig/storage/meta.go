package storage

type ObjectMetaInfo struct {
	Cluster string
	Pool    string
}
